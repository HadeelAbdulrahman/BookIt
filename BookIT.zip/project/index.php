<html>
<head>
<title>Bookit</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<link rel="stylesheet" href="style.css">
</head>
<body>

	<header>
	<input type="checkbox" name=" " id="toggler">
	<label for="toggler" class="fas fa-bars"></label>
	<a href="#" class="logo">BookiT<span>.</span></a>
	<nav class="navbar">
		<a href="#home">home</a>
		<a href="#about">about</a>
		<a href="#products">products</a>
		
	</nav>
	<div class="icons">
		<a href="#" class="fas fa-heart"></a>
		<a href="#" class="fas fa-shopping-cart"></a>
		<a href="userAccs.php" class="fas fa-user"></a>
	</div>
	</header>
	
	<section class="home" id="home">
		<div class="content">
			<h3> Hotel Booking</h3>
			<span>fast and easy</span>
			<p>view and book all your favourite hotels from all over the world</p>
			<a href="#products" class="btn">book now</a>
		</div>
	</section>
	
	<section class="about" id="about">
		<h1 class="heading"><span> about </span> us </h1>
		<div class="row">
			<video style="width:95%; height: 90%px;" src="vidhotel.mp4" loop autoplay muted></video>
			<h3>best online booking website</h3>
		</div>
		<div class="content">
			<h3>why choose us?</h3>
			<p>Discover why BookiT is your ultimate travel companion. With a user-friendly interface, extensive accommodation options, unbeatable deals, and a commitment to reliability, trust, and exceptional customer support, we make booking your next adventure a breeze.</p>
			<p> Benefit from our flexible booking options and let us help you create unforgettable memories. Choose [Your Website Name] and embark on your next journey with confidence.</p>
			<a href="#" class="btn">learn more</a>
		</div>
	</section>
	<section class="products" id="products">
		<h1 class="heading">luxury <span>hotels</span></h1>
		<div class="box-container">
			<div class="box">
				<span class="discount">-10%</span>
				<div class="image">
					<a href="book.php"><img src="aquaviva.jpeg" alt="img"></a>
					<div class="icons">
						<a href="#" class="fas fa-heart"></a>
						<a href="book.php" class="cart-btn">Book now</a>
						<a href="#" class="fas fa-share"></a>
					</div>
				</div>
				<div class="content">
					<h3>Jazz Aquaviva</h3>
					<div class="price">$12.99<span>$15.99</span></div>
				</div>
			</div>
			<div class="box">
				<span class="discount">-10%</span>
				<div class="image">
					<a href="fourS.php"><img src="fourS.jpeg" alt="img"></a>
					<div class="icons">
						<a href="#" class="fas fa-heart"></a>
						<a href="fourS.php" class="cart-btn">Book now</a>
						<a href="#" class="fas fa-share"></a>
					</div>
				</div>
				<div class="content">
					<h3>Four Seasons</h3>
					<div class="price">$12.99<span>$15.99</span></div>
				</div>
			</div>
			
			
			<div class="box">
				<span class="discount">-10%</span>
				<div class="image">
					<a href="rixosBook.php"><img src="rixos.jpeg" alt="img"></a>
					<div class="icons">
						<a href="#" class="fas fa-heart"></a>
						<a href="rixosBook.php" class="cart-btn">Book now</a>
						<a href="#" class="fas fa-share"></a>
					</div>
				</div>
				<div class="content">
					<h3>Rixos Hurghada</h3>
					<div class="price">$12.99<span>$15.99</span></div>
				</div>
</div>
		</div>
	</section>
</body>
</html>