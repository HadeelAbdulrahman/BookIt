<html>
    <head>
</head>
<body>

<?php
 $servername="localhost";
 $username="root";
 $password="";
 $db="hotel";
 $conn = new mysqli($servername,$username,$password,$db);
 if($conn-> connect_error)
 {
     die("connection failed: ".$conn->connect_error);
 }
 if(isset($_POST['username']) && isset($_POST['pass']))
 {
    $user=$_POST['username'];
    $sql = "select pass FROM User WHERE username='$user'";
    $result = mysqli_query($conn, $sql);
    $numrows = mysqli_num_rows($result);
    if($numrows>0)
    {
        $row = mysqli_fetch_assoc($result);
    $stored_pass = $row['pass'];
        if($_POST['pass']==$stored_pass) 
        {
            header("Location: index.php");
            exit();
        }

    } else {echo 'Not Found :( ';}
    }
    $stmt->close();
 $conn->close();
?>
</body>
</html>