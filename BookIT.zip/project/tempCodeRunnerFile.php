<?php
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox


def exit_game():
    root.destroy()


def show_help():
    help_info = """
    Welcome to the Escape Room and Characters with Superpowers Virtual World Game!

    How to Play:
    1. Choose your favorite character.
    2. Navigate through the virtual world to solve puzzles and challenges.
    3. Use your character's superpowers to overcome obstacles.
    4. Escape from the virtual room to win the game!

    Have fun playing!
    """
    messagebox.showinfo("Help", help_info)


def login():
    def verify_login():
        username = username_entry.get()
        password = password_entry.get()

        if username == "Dr ehab" and password == "MRD":
            messagebox.showinfo("Login Successful", "Welcome, Dr ehab!")
            level1_button.config(state="normal")
            login_dialog.destroy()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password. Please try again.")

    login_dialog = tk.Toplevel(root)
    login_dialog.title("Login")
    login_dialog.configure(bg="#000000")
    login_dialog.geometry("300x150")

    username_label = tk.Label(login_dialog, text="Username:", bg="#000000", fg="white")
    username_label.pack()
    username_entry = tk.Entry(login_dialog)
    username_entry.pack()

    password_label = tk.Label(login_dialog, text="Password:", bg="#000000", fg="white")
    password_label.pack()
    password_entry = tk.Entry(login_dialog, show="*")
    password_entry.pack()

    login_button = tk.Button(login_dialog, text="Login", command=verify_login, bg="#16A085", fg="white")
    login_button.pack()


def choose_character():
    global choose_character_button  # Define as global
    character_dialog = tk.Toplevel(root)
    character_dialog.title("Choose Character")
    character_dialog.configure(bg="#34495E")

    def select_character(event):
        item = character_tree.selection()[0]
        character = character_tree.item(item, "text")
        superpower = character_tree.item(item, "values")[0]
        show_character_info(character, superpower)

    character_tree = ttk.Treeview(character_dialog, columns=("Superpower"), style="Custom.Treeview")
    character_tree.heading("#0", text="Character")
    character_tree.heading("Superpower", text="Superpower")
    character_tree.insert("", "end", text="Batman", values=("Stealth in the Shadows"))
    character_tree.insert("", "end", text="Wolverine", values=("Claws"))
    character_tree.insert("", "end", text="Loki", values=("Manipulation of Time"))
    character_tree.insert("", "end", text="Flash", values=("Super Speed"))
    character_tree.insert("", "end", text="Superman", values=("Flight"))
    character_tree.insert("", "end", text="Wonder Woman", values=("Lasso of Truth"))
    character_tree.insert("", "end", text="Iron Man", values=("Powered Armor"))
    character_tree.insert("", "end", text="Captain America", values=("Superhuman Strength"))
    character_tree.insert("", "end", text="Spiderman", values=("Wall-crawling"))
    character_tree.insert("", "end", text="Doctor Strange", values=("Mystic Arts"))
    character_tree.bind("<Double-1>", select_character)
    character_tree.pack(padx=10, pady=10)

    character_tree.tag_configure("oddrow", background="#2C3E50")
    character_tree.tag_configure("evenrow", background="#34495E")

    choose_character_button = tk.Button(game_screen, text="Choose Character", font=("Helvetica", 14), padx=10, pady=5,
                                        bg="#16A085", fg="#FFFFFF", command=choose_character)
    choose_character_button.pack(side=tk.LEFT, padx=5)


def show_character_info(character, superpower):
    print(f"Selected Character: {character}")
    print(f"Superpower: {superpower}")
    print("Actions:")
    actions = ['move [direction]', 'look', 'inventory', f'use [{superpower}]']
    for action in actions:
        print("- " + action)


def open_door_interface():
    door_width = 800
    door_height = 600

    door_window = tk.Toplevel(root)
    door_window.title("Door Interface")
    door_window.geometry(f"{door_width}x{door_height}")  # Set the size of the door interface window

    door_canvas = tk.Canvas(door_window, bg="#2C3E50", width=door_width, height=door_height)
    door_canvas.pack()

    door_canvas.create_rectangle(50, 50, door_width - 50, door_height - 50, fill="#000000", outline="#8B4513",
                                 width=6)  # Door frame
    door_canvas.create_oval(door_width // 2 - 20, door_height - 120, door_width // 2 + 20, door_height - 80,
                            fill="#FF4500")  # Door knob

    exit_button = tk.Button(door_canvas, text="Exit Game", font=("Helvetica", 12, "bold"), command=exit_game,
                            bg="#FFA500", fg="#FFFFFF", relief=tk.RAISED, padx=10, pady=5)
    exit_button.place(relx=0.5, rely=0.6, anchor=tk.CENTER)

    help_button = tk.Button(door_canvas, text="Help", font=("Helvetica", 12, "bold"), command=show_help, bg="#FFA500",
                            fg="#FFFFFF", relief=tk.RAISED, padx=10, pady=5)
    help_button.place(relx=0.3, rely=0.5, anchor=tk.CENTER)

    choose_character_button.pack(side=tk.LEFT, padx=5)


def open_level1():
    print("Entering Level 1...")
    choose_character()


root = tk.Tk()
root.title("Escape Game")

style = ttk.Style()
style.theme_use("clam")
style.configure("Custom.Treeview", background="#34495E", fieldbackground="#34495E", foreground="#FFFFFF",
                font=("Helvetica", 12))
style.map("Custom.Treeview", background=[("selected", "#16A085")])

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

root.configure(bg="#2C3E50")

game_screen = tk.Frame(root, bg="#2C3E50")
game_screen.pack(padx=10, pady=10)

label_info = tk.Label(game_screen, text="Welcome to the Escape Game!", font=("Helvetica", 18), fg="#FFFFFF",
                      bg="#2C3E50")
label_info.pack(pady=20)

button_help = tk.Button(game_screen, text="Help", font=("Helvetica", 14), padx=10, pady=5, bg="#16A085",
                        fg="#FFFFFF", command=show_help)
button_help.pack(side=tk.LEFT, padx=5)

button_exit = tk.Button(game_screen, text="Exit", font=("Helvetica", 14), padx=10, pady=5, bg="#16A085",
                        fg="#FFFFFF", command=exit_game)
button_exit.pack(side=tk.LEFT, padx=5)

button_login = tk.Button(game_screen, text="Login", font=("Helvetica", 14), padx=10, pady=5, bg="#16A085",
                         fg="#FFFFFF", command=login)
button_login.pack(side=tk.LEFT, padx=5)

level1_button = tk.Button(game_screen, text="Level 1", font=("Helvetica", 14), padx=10, pady=5, bg="#16A085",
                          fg="#FFFFFF", state="disabled", command=open_level1)
level1_button.pack(side=tk.LEFT, padx=5)

root.mainloop()