<?php
function connectToDatabase() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "hotel";
    $conn = new mysqli($servername, $username, $password, $db);
    if ($conn->connect_error) {
        die("Connection failed: ". $conn->connect_error);
    }
    return $conn;
}

function createTable($conn, $sql) {
    if (mysqli_query($conn, $sql)) {
        echo "Table created successfully";
    } else {
        echo "Error creating table: ". mysqli_error($conn);
    }
}



$conn = connectToDatabase();

$sql1 = "CREATE TABLE User (
    id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    firstname VARCHAR(20) NOT NULL,
    lastname VARCHAR(20),
    email VARCHAR(50),
    phone VARCHAR(11),
    username VARCHAR(10),
    pass VARCHAR(8),
    admin VARCHAR(10)
)";
createTable($conn, $sql1);

$sql2 = "CREATE TABLE Aquaviva (
    B_id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    B_noGuests INT(10) not null,
    B_Rtype varchar(20) not null,
    B_inDate date not null,
    B_outDate date not null
)";
createTable($conn, $sql2);

$sql3 = "CREATE TABLE FourSeasons (
    B_id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    B_noGuests INT(10) not null,
    B_Rtype varchar(20) not null,
    B_inDate date not null,
    B_outDate date not null
)";
createTable($conn, $sql3);

$sql4 = "CREATE TABLE Rixos (
    B_id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    B_noGuests INT(10) not null,
    B_Rtype varchar(20) not null,
    B_inDate date not null,
    B_outDate date not null
)";
createTable($conn, $sql4);

$conn->close();
?>