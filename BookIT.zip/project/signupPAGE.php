<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8"/>
    <title>Signup page</title>
    <style>
        h1 {
            text-align: center;
            font-family: cursive;
            color: #8B4513;
        }
        body {
            font-family: cursive;
            background-image: url("color.png");
            background-position: center;
            background-size: cover;
            text-align: center;
        }
        td {
            text-align: left;
            padding: 10px;
        }
        img {
            width: 250px;
            height: 250px;
            position: absolute;
            top: 0;
            left: 0;
            margin: 10px;
        }
    </style>
</head>
<body>
    <form style="margin-top: 130px;" method="post" action="">
        <h1>Signup page</h1>
        <fieldset>
            <legend>Signup</legend>
            <table style="margin: auto;">
                <tr>
                    <td>First Name:</td>
                    <td><input type="text" name="firstname"></td>
                </tr>
                <tr>
                    <td>Last Name:</td>
                    <td><input type="text" name="lastname"></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><input type="email" name="email"></td>
                </tr>
                <tr>
                    <td>Username:</td>
                    <td><input type="text" name="username"></td>
                </tr>
                <tr>
                    <td>Password:</td>
                    <td><input type="password" name="password"></td>
                </tr>
            </table>
        </fieldset>
        <br>
        <input type="submit" name="submit" value="Sign Up">
    </form>

    <?php
    if(isset($_POST['submit'])) {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $db = "hotel";
        $conn = new mysqli($servername, $username, $password, $db);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if (isset($_POST['firstname']) && isset($_POST['lastname']) && isset($_POST['email']) && isset($_POST['username']) && isset($_POST['password'])) {
            $stmt = $conn->prepare("INSERT INTO User (firstname, lastname, email, username, pass) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $_POST['firstname'], $_POST['lastname'], $_POST['email'], $_POST['username'], $_POST['password']);
            if ($stmt->execute()) {
                header("Location: index.php");
                exit();
            }
            $stmt->close();
            $conn->close();
        }
    }
    ?>
</body>
</html>
