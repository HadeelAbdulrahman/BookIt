<html>
	<head>
	<title>db creation</title>
	</head>
	<body>
		<?php
		  $servername="localhost";
		  $username="root";
		  $password="root";
		  echo'test';
		  $conn= new mysqli($servername,$username,$password);
		  echo'test';
		  if($conn->connect_error)
		  {
		      die("connection failed: ".$conn->connect_error);
		  }
		  
		  $sql="create database hotel";
		  if($conn->query($sql)==TRUE)
		  {
		      echo"database hotel created successfully";
		  }else
		  {
		      echo "error creating DB: ".$conn->error;
		  }
		  #$conn->select_db("hotel");
		  $conn->close();
		      
		?>
	</body>
</html>




