<html>
<head>
	<title>user acc</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<link rel="stylesheet" href="style.css">
</head>
<body>
	<header>
	<input type="checkbox" name=" " id="toggler">
	<label for="toggler" class="fas fa-bars"></label>
	<a href="#" class="logo">BookiT<span>.</span></a>
	<nav class="navbar">
		<a href="index.php">home</a>
		<a href="index.php">about</a>
		<a href="index.php">products</a>
		
	</nav>
	<div class="icons">
		<a href="#" class="fas fa-heart"></a>
		<a href="#" class="fas fa-shopping-cart"></a>
		<a href="#" class="fas fa-user"></a>
	</div>
	</header>
	
	<section class="user" id="user">
		<<h1 style=" margin-top: 5rem;" class="heading">Manage <span>Account</span></h1>
		<div class="box-container">
			<div class="box">
			<a href="loginPage.php" class="logout">Log Out</a><br>
			</div>
		</div>
		<div class="box-container">
			<div class="box">
			<a href="#" class="update">Update Acc: </a>
			</div>
		</div>
		</div>
		<section class="update" id="update">
			<form method="post" action="">
    <table>
    <tr>
    		<td> <input type="text" placeholder="User ID" name="id"/></td>
    	</tr>
    	<tr style="height: 20px;">
		</tr>
    	<tr>
    		<td> <input type="text" placeholder="First name" name="Fname"/></td>
    	</tr>
    	<tr style="height: 20px;">
		</tr>
    	<tr>
    		<td> <input type="text" placeholder="Last name" name="Lname"/></td>
    	</tr>
    	<tr style="height: 20px;">
		</tr>
    	<tr>
    		<td> <input type="text" placeholder="Email" name="email"/></td>
    	</tr>
    	<tr style="height: 20px;">
		</tr>
    	<tr>
    		<td> <input type="text" placeholder="Phone no" name="phone"/></td>
    	</tr>
    	<tr style="height: 20px;">
		</tr>
    	<tr>
    		<td> <input type="text" placeholder="Username" name="username"/></td>
    	</tr>
    	<tr style="height: 20px;">
		</tr>
    	<tr>
    		<td> <input type="text" placeholder="Password" name="pass"/></td>
    	</tr>
    	<tr style="height: 20px;">
		</tr>
    	<tr>
    		<td> <input class="button" type="submit"  name="Update info"/></td>
    	</tr>
    </table>
    </form>
    <?php 
	$servername="localhost";
	$username="root";
	$password="";
	$db="hotel";
	$conn = new mysqli($servername,$username,$password,$db);
	if($conn-> connect_error)
	{
	    die("connection failed: ".$conn->connect_error);
	}
	if(isset($_POST['id'])&& isset($_POST['Fname'])&&isset($_POST['Lname'])&& isset($_POST['email']) && isset($_POST['phone'])&& isset($_POST['username'])&& isset($_POST['pass']))
	{
        $stmt=$conn->prepare("update User set firstname=?, lastname=?, email=?, phone=?, username=?, pass=? where id=?");
        $stmt->bind_param("sssssss",$_POST['Fname'],$_POST['Lname'],$_POST['email'],$_POST['phone'],$_POST['username'],$_POST['pass'],$_POST['id']);
        if($stmt->execute())
        {
            header("Location: index.php?update=done");
            exit();
        }
       $conn->close(); 
	}
	?>
			
		</section>
	</section>
</body>
</html>