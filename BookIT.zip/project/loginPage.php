<html>
<head>
    
    <title> Login BookiT</title>
    <style>
        body 
        {
           
           font-family: cursive;
           background-image: url("color.png");
           background-position: center;
           background-size: cover;
        }
        .button 
        {
            width: 100px;
            height: 25px;
            font-size: 15px;
            margin-top: 15px;
            margin-right: 15px;
        }
    </style>

</head>
<body>
    <img src="logo.png" style="height: 350px;width: 350px; margin-left: 40%;"/>
    <form method="Post" action="loginFINAL.php">
        <table width="100%" style="text-align:center;" >
            <tr>
                <td> Username:   <input type="text" name="username"/></td>
            </tr>
            <tr>
                <td>Password:   <input type="password" name="pass"/></td>
            <tr >
                <td>
                     <input type="submit" value="login" class="button"/>
                     or 
                    
                    <label> <a  href="signupPAGE.php" >Signup</a></label>
               </td>
                
            </tr>
        </table>
    </form>
    
   
</body>
</html>
