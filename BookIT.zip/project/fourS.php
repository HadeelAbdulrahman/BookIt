<html>
<head>
<title>Booking</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
	<input type="checkbox" name=" " id="toggler">
	<label for="toggler" class="fas fa-bars"></label>
	<a href="#" class="logo">BookiT<span>.</span></a>
	<nav class="navbar">
		<a href="index.php">home</a>
		<a href="index.php">about</a>
		<a href="index.php">products</a>
		<a href="contact.php">contact</a>
	</nav>
	<div class="icons">
		<a href="#" class="fas fa-heart"></a>
		<a href="#" class="fas fa-shopping-cart"></a>
		<a href="userAccs.php" class="fas fa-user"></a>
	</div>
	</header>
	<section class="book" id="book">
		<<h1 style="margin-top:7rem;" class="heading">Book <span>Rooms</span></h1>
		<div class="box-container">
			<div class="box">
			<span>Booking Details (Four Seasons)</span><br>
			</div>
		</div>
	<section class="book" id="book">
        
<form method="post" action="">
<table>
    <tr>
        <td><input type="int" placeholder="no of guests" name="guestno"/></td>
    </tr>
    <tr style="height: 2rem;">
   </tr>
	<tr>
		<td><input type="text" placeholder="Room type" name="Rtype"/></td>
	</tr>
    <tr style="height: 2rem;">
   </tr>
	<tr>
		<td><input type="date" placeholder="checkin date" name="indate"/></td>
	</tr>
    <tr style="height: 2rem;">
    </tr>
	<tr>
		<td><input type="date" placeholder="checkout date" name="outdate"/></td>
	</tr>
    <tr style="height: 2rem;">
    </tr>
    <tr>
        <td><input type="submit" name="submit booking"/></td>
    </tr>

</table>
</form>

</section>
<?php 
    $servername="localhost";
    $username="root";
    $password="";
    $db="hotel";
    $conn = new mysqli($servername,$username,$password,$db);
    if($conn-> connect_error)
    {
        die("connection failed: ".$conn->connect_error);
    }
    if(isset($_POST['guestno'])&& isset($_POST['Rtype'])&& isset($_POST['indate'])&& isset($_POST['outdate']))
    {
        $stmt=$conn->prepare("INSERT INTO fourseasons (B_noGuests,B_Rtype,B_inDate,B_outDate) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss",$_POST['guestno'], $_POST['Rtype'],$_POST['indate'],$_POST['outdate']);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit();
        }
        $stmt->close();
        $conn->close();
    }
?>

</body>
</html>
